<?php
	include('bd.php');
	
	// Получаем ID пользователя
	$firstname = $_GET['first_name'];
	$lastname = $_GET['last_name'];
	$test1 = $_GET['test1'];
	$test2 = $_GET['test2'];
	$test3 = $_GET['test3'];
	
	$query = "INSERT INTO `students` (first_name,last_name,test_1,test_2,test_3) VALUES('$firstname', '$lastname', '$test1', '$test2', '$test3')";
	$result = mysql_query($query); 
	
	if($result)
		$json_data = array ('status'=>1);
	else
		die(mysql_error());
	mysql_close();
	$json_data = array ('First Name'=>$firstname, 'last_name'=>$lastname, 'test1'=>$test1,'test2'=>$test2,'test3' => $test3);
	echo json_encode($json_data, JSON_UNESCAPED_UNICODE);
?>
