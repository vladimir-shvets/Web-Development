<?php
	include('bd.php');
	$uploaddir = '';
	$file = basename($_FILES['userfile']['name']);
	$uploadfile = $uploaddir . $file;
	
	if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
		echo "http://www.vova2.mafftor.ru/wp-content/uploads/certificates/{$file}";
	}
	$id = $_GET['id'];
	$query = "SELECT * FROM answers WHERE id='$id'";
	$result = mysql_query($query);
	if($result)
		$row = mysql_fetch_array($result);
	else
		die(mysql_error());
	/*
	for($i=1;$i<7;$i++)
	{
		if($row['certificate_'.$i]== ""){
			$query = "UPDATE answers WHERE id='$id'";
			$result = mysql_query($query);
			if($result)
				$row = mysql_fetch_array($result);
			else
				die(mysql_error());

		}
		
	}
	*/
	var_dump($row);
?>