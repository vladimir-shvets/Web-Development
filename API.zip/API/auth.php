<?php
	include('bd.php');
	require_once($_SERVER['DOCUMENT_ROOT']."/wp/wp-load.php");
	$query = "SELECT * FROM `wp_users`";
	$result = mysql_query($query);
	if(!$result) echo "error";
	
	while($row = mysql_fetch_array($result))
	{
		if($_GET['login'] == $row['user_login'])
		{
			if(wp_check_password($_GET['pwd'], $row['user_pass']))
			{
				echo true;
			}
		}
	}
	
	
	$json_data = array ('id'=>1,'name'=>"ivan",'country'=>'Russia',"office"=>array("yandex"," management"));
	//echo json_encode($json_data);
?>