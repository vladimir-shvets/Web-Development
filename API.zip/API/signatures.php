<?php

	$uploaddir = 'certificates';
	$file = basename($_FILES['userfile']['name']);
	$uploadfile = $uploaddir . $file;
	
	if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
		echo "http://www.vova2.mafftor.ru/signatures/{$file}";
	}
	
?>