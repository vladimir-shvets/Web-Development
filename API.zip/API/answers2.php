<?php
	include('bd.php');
	require_once($_SERVER['DOCUMENT_ROOT']."/wp/wp-load.php");
	
	
	
	
	$firstname = $_GET['firstname'];
	$lastname = $_GET['lastname'];
	$date = $_GET['date'];
	$signature = $_GET['signature'];
	
	$q1_1 = $_GET['q1_1'];
	$q1_2 = $_GET['q1_2'];
	$q1_3 = $_GET['q1_3'];
	
	$s1_1 = $_GET['s1_1'];
	$s1_2 = $_GET['s1_2'];
	$s1_3 = $_GET['s1_3'];
	$s1_4 = $_GET['s1_4'];
	$s1_5 = $_GET['s1_5'];
	$s1_6 = $_GET['s1_6'];
	$s1_7 = $_GET['s1_7'];
	$s1_8 = $_GET['s1_8'];
	$s1_9 = $_GET['s1_9'];
	$s1_10 = $_GET['s1_10'];
	$s1_11 = $_GET['s1_11'];
	$s1_12 = $_GET['s1_12'];
	$s1_13 = $_GET['s1_13'];
	$s1_14 = $_GET['s1_14'];
	$s1_15 = $_GET['s1_15'];
	$s1_16 = $_GET['s1_16'];
	$s1_17 = $_GET['s1_17'];
	$s1_18 = $_GET['s1_18'];
	$s1_19 = $_GET['s1_19'];
	$s1_20 = $_GET['s1_20'];
	
	$s2_1 = $_GET['s2_1'];
	$s2_2 = $_GET['s2_2'];
	$s2_3 = $_GET['s2_3'];
	$s2_4 = $_GET['s2_4'];
	$s2_5 = $_GET['s2_5'];
	$s2_6 = $_GET['s2_6'];
	$s2_7 = $_GET['s2_7'];
	$s2_8 = $_GET['s2_8'];
	$s2_9 = $_GET['s2_9'];
	$s2_10 = $_GET['s2_10'];
	
	$s3_1 = $_GET['s3_1'];
	$s3_2 = $_GET['s3_2'];
	$s3_3 = $_GET['s3_3'];
	$s3_4 = $_GET['s3_4'];
	$s3_5 = $_GET['s3_5'];
	$s3_6 = $_GET['s3_6'];
	
	//C O M M E N T S
	$comment_q1_1 = $_GET['comment_q1_1'];
	$comment_q1_2 = $_GET['comment_q1_2'];
	$comment_q1_3 = $_GET['comment_q1_3'];
	
	$comment_s1_1 = $_GET['comment_s1_1'];
	$comment_s1_2 = $_GET['comment_s1_2'];
	$comment_s1_3 = $_GET['comment_s1_3'];
	$comment_s1_4 = $_GET['comment_s1_4'];
	$comment_s1_5 = $_GET['comment_s1_5'];
	$comment_s1_6 = $_GET['comment_s1_6'];
	$comment_s1_7 = $_GET['comment_s1_7'];
	$comment_s1_8 = $_GET['comment_s1_8'];
	$comment_s1_9 = $_GET['comment_s1_9'];
	$comment_s1_10 = $_GET['comment_s1_10'];
	$comment_s1_11 = $_GET['comment_s1_11'];
	$comment_s1_12 = $_GET['comment_s1_12'];
	$comment_s1_13 = $_GET['comment_s1_13'];
	$comment_s1_14 = $_GET['comment_s1_14'];
	$comment_s1_15 = $_GET['comment_s1_15'];
	$comment_s1_16 = $_GET['comment_s1_16'];
	$comment_s1_17 = $_GET['comment_s1_17'];
	$comment_s1_18 = $_GET['comment_s1_18'];
	$comment_s1_19 = $_GET['comment_s1_19'];
	$comment_s1_20 = $_GET['comment_s1_20'];
	
	$comment_s2_1 = $_GET['comment_s2_1'];
	$comment_s2_2 = $_GET['comment_s2_2'];
	$comment_s2_3 = $_GET['comment_s2_3'];
	$comment_s2_4 = $_GET['comment_s2_4'];
	
	$comment_s3_1 = $_GET['comment_s3_1'];
	$comment_s3_2 = $_GET['comment_s3_2'];
	$comment_s3_3 = $_GET['comment_s3_3'];
	$comment_s3_4 = $_GET['comment_s3_4'];
	$comment_s3_5 = $_GET['comment_s3_5'];
	$comment_s3_6 = $_GET['comment_s3_6'];
	
	$certificate_1 = $_GET['certificate_1'];
	$certificate_1 = $_GET['certificate_2'];
	$certificate_1 = $_GET['certificate_3'];
	$certificate_1 = $_GET['certificate_4'];
	$certificate_1 = $_GET['certificate_5'];
	$certificate_1 = $_GET['certificate_6'];
	
	$signature = $_GET['signature'];
	

	$query = "INSERT INTO `answers` (firstname,lastname,date,signature,url,q1_1, q1_2, q1_3, s1_1, s1_2, s1_3, s1_4, s1_5, s1_6,s1_7, s1_8, s1_9, s1_10, s1_11, s1_12, s1_13, s1_14, s1_15, s1_16, s1_17, s1_18, s1_19, s1_20, s2_1, s2_2, s2_3, s2_4, s3_1, s3_2, s3_3, s3_4, s3_5, s3_6, certificate_1,certificate_2, certificate_3, certificate_4, certificate_5, certificate_6) VALUES ('$firstname','$lastname','$date','$signature','','$q1_1','$q1_2','$q1_3', '$s1_1','$s1_2','$s1_3','$s1_4','$s1_5','$s1_6','$s1_7','$s1_8','$s1_9','$s1_10','$s1_11','$s1_12','$s1_13','$s1_14','$s1_15','$s1_16','$s1_17','$s1_18','$s1_19','$s1_20','$s2_1','$s2_2','$s2_3','$s2_4','$s3_1','$s3_2','$s3_3','$s3_4','$s3_5','$s3_6','$certificate_1','$certificate_2','$certificate_3','$certificate_4','$certificate_5','$certificate_6') ";
	
	$result = mysql_query($query);
	
	$myurl = @"http://vova2.mafftor.ru/wp-content/uploads/invoice.php?id=";
	
	$myid = mysql_insert_id();

	$sql = "UPDATE `answers` SET url='".$myurl."".$myid."' WHERE id='".$myid."'";
	$ress = mysql_query($sql);
	if(!$ress) die(mysql_error());
	
	if($result)
		$json_data = array ('status'=>1);
	else
		die(mysql_error());
	//	$json_data = array ('status'=>0);
	
	
$json_data = array ('ID'=>$myid);
	echo json_encode($json_data, JSON_UNESCAPED_UNICODE);

	
?>