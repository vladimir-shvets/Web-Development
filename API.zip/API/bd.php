<?php
	header("Content-Type:text/html;charset=UTF-8");
	$db = mysql_connect ("localhost", "pixem_vova21", "c9a3bb5a") or die(mysql_error());
	mysql_select_db ("pixem_vova21", $db);
?>