<?php
header("Content-Type:text/html;charset=UTF-8");
$db = mysql_connect ("localhost", "pixem_vova21", "c9a3bb5a") or die(mysql_error());
mysql_select_db ("pixem_vova21", $db);

// Получаем ID пользователя
//$id = $_GET['user_id'];

//Выбираем все записи
$query = "SELECT * FROM wp_posts WHERE post_status='publish' AND post_type='post'";

//В переменной $res сохраняем результаты выборки
$result = mysql_query($query); 

$query1 = "SELECT * FROM wp_term_relationships";
$result1 = mysql_query($query1); 

//В цикле выводим по очереди все полученные строки
//var_dump($result);
$arr = array();
$arr1 = array();

/*
while (($row = mysql_fetch_array($result)))
{
array_push($arr, array('content' => $row['post_content'],'Categories' => $row1['name']));
} 
while ($row = mysql_fetch_array($result1))
{
array_push($arr1, array('Categorie' => $row['name']));
} 
*/


while ($row = mysql_fetch_array($result))
{
$query2 = "SELECT * FROM wp_term_relationships WHERE object_id='".$row['ID']."' ";
$result2 = mysql_query($query2);
if($result2)
$row2=mysql_fetch_array($result2);
else
die(mysql_error());

$query3 = "SELECT * FROM wp_terms WHERE term_id='".$row2['term_taxonomy_id']."' ";
$result3 = mysql_query($query3);
if($result3)
$row3=mysql_fetch_array($result3);
else
die(mysql_error());

array_push($arr, array('content' => $row['post_content'],/*'testID' => $row['ID'],*/'Category' => $row3['name']));
} 
/*
while ($row = mysql_fetch_array($result1))
{
array_push($arr1, array('Categorie' => $row['name']));
}
*/
mysql_close();

echo "{\"response\":";
echo json_encode($arr, JSON_UNESCAPED_UNICODE);
echo "}"
?>