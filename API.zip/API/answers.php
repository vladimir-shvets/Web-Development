<?php
	include('bd.php');
	$id = $_GET['id'];

	$multi = explode(',',$id);
	
	$mark = $_GET['mark'];
	
	$marks = explode(',',$mark);
	
	//Выбираем все записи
	$query = "SELECT * FROM wp_posts WHERE post_status='publish' AND post_type='post'";
	//В переменной $res сохраняем результаты выборки
	$result = mysql_query($query); 
	if(!$result)
		die(mysql_error());
	
	for($i = 0; $row = mysql_fetch_array($result); $i++)
	{
		for($j = 0; $j < count($multi); $j++)
		{
			if($row['ID'] == $multi[$j])
			{
				if($marks[$j]==1)
				{
					$pass = "S";
				}
				else
				{
					$pass = "UN";
				}
				$title .= $row['post_title']." ". $pass;
				$content .= $row['post_content'];
			}
		}
	}
	echo $title;
	echo $content;
?>