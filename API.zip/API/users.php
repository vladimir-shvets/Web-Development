<?php
	include('bd.php');
	
	// Получаем ID пользователя
	$id = $_GET['user_id'];
	
	
	$rank = "SELECT *FROM wp_usermeta WHERE user_id='$id' AND meta_key='wp_user_level'";
	$res = mysql_query($rank); 
	
	while ($row = mysql_fetch_array($res))
	{
		 $userrank = $row['meta_value'];
		 
	}
	//echo "User level - ".$userrank." <br />";
	
	if($userrank == 10)
	{
	 	//echo "Status: Admin <br />";
	 	$jrank = 10;
	}
	else if($userrank == 2)
	{
		//echo "Status: User <br />";
		$jrank = 2;
	}
	
	
	//Выбираем все записи
	$query = "SELECT * FROM wp_usermeta WHERE user_id='$id' AND meta_key='first_name'";
	//В переменной $res сохраняем результаты выборки
	$result = mysql_query($query); 
	
	//В цикле выводим по очереди все полученные строки
	//var_dump($result);
	while ($row = mysql_fetch_array($result))
	{
		 $firstname = $row['meta_value'];
	}	
	//Выбираем все записи
	$query = "SELECT * FROM wp_usermeta WHERE user_id='$id' AND meta_key='last_name'";
	//В переменной $res сохраняем результаты выборки
	$result = mysql_query($query);  
	 
	//В цикле выводим по очереди все полученные строки
	//var_dump($result);
	while ($row = mysql_fetch_array($result))
	{
		 $lastname = $row['meta_value'];
	}
	
	$query = "SELECT * FROM wp_usermeta WHERE user_id='$id' AND meta_key='userphoto_image_file'";
	$result = mysql_query($query);
	
	while($row = mysql_fetch_array($result))
	{
		$image = $row['meta_value'];
	}
	$uri = @"http://vova2.mafftor.ru/wp-content/uploads/userphoto/" . $image;
	
	mysql_close();
	
	$json_data = array ('id'=>$id, 'user_rank'=>$jrank, 'firstname'=>$firstname,'lastname'=>$lastname,'avatar' => $uri);
	echo json_encode($json_data, JSON_UNESCAPED_UNICODE);
?>
