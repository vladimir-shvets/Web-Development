<?php
	include('bd.php');
	$file = $_GET['filename'];
	$id = $_GET['id'];
	$query = "SELECT * FROM answers WHERE id='$id'";
	$result = mysql_query($query);
	if($result)
		$row = mysql_fetch_array($result);
	else
		die(mysql_error());
	
	//for($i=1;$i<7;$i++)
	//{
	
			$query = "UPDATE answers SET signature ='{$file}' WHERE id='$id'";
			$result1 = mysql_query($query);
			if(!$result1){
				die(mysql_error());
			break;
			}
				
		//}
	//}
?>