<html>
	<head>
		<meta charset="utf-8" />
		<style>
		body {
			background: linear-gradient(#ffb400, #ff9300);
			background-color: #ff9e00;
		}
		</style>
	</head>
	<body>
		<?php
			if(isset($_POST['name']) && isset($_POST['phone']))
			{
				if(!empty($_POST['name'])) $name = $_POST['name']; // Если поле не пустое, то создать и записать данные в переменную
				if(!empty($_POST['phone'])) $phone = $_POST['phone']; // Если поле не пустое, то создать и записать данные в переменную

				
				$emailTo = 'info@5fit.ru'; //Введите Ваш email куда придет письмо
				$body = "Имя: $name\nТелефон: $phone\n"; // Весь текст письма
				$headers = 'From: 5fit <'.$emailTo.'>' . "\r\n" . 'Reply-To: ' . $email; // Формируем заголовок письма
				if(mail($emailTo, 'Feedback', $body, $headers)) // Функция mail() отправляет само письмо
				{
					echo "<h1 style='display:table;margin:0 auto;margin-top:300px;font-family:Georgian;font-style:italic;'>Ваше сообщение успешно отправлено!</h1>";
					echo "<meta HTTP-EQUIV='refresh' content='2;index.php'>"; //Автоматически через 2 секунды вернет нас на главную
				}
			}		
		?>
	</body>
</html>