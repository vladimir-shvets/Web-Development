$(document).ready(function() {


	$(".more").on("click", function(){
		$('.check_more').toggle().toggleClass("vis");
		$('.more').css("display","none");
	})

	$(window).resize(function(){
		show_check();
	});
	function show_check(){
		var docWidth = $(document).width();
		if(docWidth<='768'){
			$(".more").css("display", "block");
			$(".vis").css("display","none");
			} else {
				$(".more").css("display", "none");
				$(".check_more").css("display","none");
			}	
	}



}); 