$(document).ready(function(){
  $('#frontvideo')[0].play();
});

$(document).on("scroll",function(){
  if($(document).scrollLeft()>1){      
     $('#frontvideo')[0].pause();
   }
   else
   {
     $('#frontvideo')[0].play();
   }
});