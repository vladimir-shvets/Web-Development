

$(document).ready(function(){
$("#navigation, #sun").on("click","a", function (event) {
    event.preventDefault();
    var id  = $(this).attr('href'),
        top = $(id).offset().top;
    $('body,html').animate({scrollTop: top}, 2000);
     });

});
/*
var h_hght =1300; // высота шапки
  var h_mrg = 0;    // отступ когда шапка уже не видна
  $(function(){
   $(window).scroll(function(){
      var top = $(this).scrollTop();
      var elem = $('#navigation');
      if (top+h_mrg < h_hght) {
       elem.css('top', (h_hght-top));
      } else {
       elem.css('top', h_mrg);
      }
    });
  });*/
/*
$(document).ready(function(){
$(".icon").animated("fadeIn", "fadeOut");
$(".green_line").animated("fadeInLeft", "fadeOut");
}); */
/*
var options = {
  offset: '.scrl3_nav'
}
var header1 = new Headhesive('#navigation', options);*/