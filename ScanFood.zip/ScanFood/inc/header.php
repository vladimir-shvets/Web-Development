<div class="headerWrapp">
	<div class="wrap">
		<div class="header">
			<a href="index.php"><img src="img/logo.png"/></a>
			<ul class="menu">
				<li><a href="#top" class="scrollto">Главная</a></li>
				<li><a href="#top1" class="scrollto">Видео</a></li>
				<li><a href="#top2" class="scrollto">Загрузить штрих</a></li>
				<li><a href="#top3" class="scrollto">Партнеры</a></li>
				<li><a href="#top4" class="scrollto">Контакты</a></li>
			</ul>
		</div>
	</div>
</div>
