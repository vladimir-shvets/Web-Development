<html>
	<head>
		<meta charset="utf-8" />
		<style>
		body {
			background-color: #e4e4e4;
		}
		</style>
	</head>
	<body>
		<?php
			if(isset($_POST['submit']))
			{
				if(!empty($_POST['name'])) $name = $_POST['name']; // Если поле не пустое, то создать и записать данные в переменную
				if(!empty($_POST['email'])) $email = $_POST['email']; // Если поле не пустое, то создать и записать данные в переменную
				if(!empty($_POST['phone'])) $phone = $_POST['phone']; // Если поле не пустое, то создать и записать данные в переменную
				if(!empty($_POST['message'])) $msg = $_POST['message']; // Если поле не пустое, то создать и записать данные в переменную
				
				$emailTo = 'vova-winner@yandex.ru'; //Введите Ваш email куда придет письмо
				$body = "Имя: $name\nEmail: $email\nТелефон: $phone\nСообщение: $msg"; // Весь текст письма
				$headers = 'From: ScanFood <'.$emailTo.'>' . "\r\n" . 'Reply-To: ' . $email; // Формируем заголовок письма
				if(mail($emailTo, 'Feedback', $body, $headers)) // Функция mail() отправляет само письмо
				{
					echo "<h1 style='display:table;margin:0 auto;margin-top:300px;font-family:Georgian;font-style:italic;'>Ваше сообщение успешно отправлено!</h1>";
					echo "<meta HTTP-EQUIV='refresh' content='2;../index.php'>"; //Автоматически через 2 секунды вернет нас на главную
				}
			}		
		?>
	</body>
</html>