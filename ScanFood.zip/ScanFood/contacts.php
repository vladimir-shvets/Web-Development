<!DOCTYPE html/>
<html>
	<head>
		<meta charset="utf-8"/>
		<link rel="shortcut icon" href="img/favicon.png">
		<title>ScanFood</title>
		<link rel="stylesheet" href="css/style.css" type="text/css"/>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
		<script src="js/adaptetion.js"></script>
	</head>

	<body>
		<?php 
			include ('inc/header.php');
		?>
		

	
			   <script>
					document.getElementById('feedback-form').onsubmit = function(){
					  var http = new XMLHttpRequest();
					  http.open("POST", "inc/post-1.php", true);
					  http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
					  http.send("nameFF=" + this.nameFF.value + "&contactFF=" + this.contactFF.value + "&messageFF=" + this.messageFF.value);
					  http.onreadystatechange = function() {
					    if (http.readyState == 4 && http.status == 200) {
					      alert(http.responseText + ', Ваше сообщение получено.\nМы свяжемся с Вами\nБлагодарим за интерес к нашей фирме!');
					    }
					  }
					  http.onerror = function() {
					    alert('Извините, данные не были переданы');
					  }
					  return false;
					}
				</script>
	
	
	<div class="contactsWrapp">
			<div class="wrap">
			<form method="POST" id="feedback-form">
			
				
				
				<input type="text" name="nameFF" required placeholder="Имя" x-autocompletetype="name">

				<input type="email" name="contactFF" required placeholder="E-mail" x-autocompletetype="email">
				
				<input type="text" name="contactFF" required placeholder="Телефон" x-autocompletetype="tel">

			
			
				<div class="contact-send">
					<textarea name="messageFF" required placeholder="Текст сообщения:" rows="12"></textarea>
				
				
					<input type="submit" value="ОТПРАВИТЬ">
					
				</div>
				
				</form>
				
			</div>
	</div>
	
	<div class="contactWrapp">
		<div class="contactText">
			<p>63000</p>
			<p>г. Новосибирск</p>
			<p>ул. Лесосечная 18, пом. II</p>
			<br/>
			<p>доп. номер: +7 923 104 40 40</p>
			<p>тел:8-(383)-328-40-01</p>
			<p>факс:8-(383)-328-40-01</p>
			<p>e-mail:http://eltsovcky@yandex.ru</p>
		</div>
		<div class="socBtnContact">
			<a target="_blank" href="http://vk.com"><img src="img/vk.png" alt=""></a>
			<a target="_blank" href="http://odnoklassniki.ru"><img src="img/od.png" alt=""></a>
			<a target="_blank" href="http://fb.com"><img src="img/fb.png" alt=""></a>
			<a target="_blank" href="http://twitter.com"><img src="img/twitter.png" alt=""></a>
			<a target="_blank" href="http://google.com"><img src="img/google.png" alt=""></a>
		</div>
	</div>
		
	</body>

</html>