<!DOCTYPE html/>
<html>
	<head>
		<meta charset="utf-8"/>
		<link rel="shortcut icon" href="img/favicon.png">
		<title>ScanFood</title>
		<link rel="stylesheet" href="css/style.css" type="text/css"/>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
		<script src="js/adaptetion.js"></script>
	</head>
	
	
	<body>
		<?php 
			include ('inc/header.php');
		?>
		
		<div class="blockBarBack">

		</div>
	
	</body>


</html>