<!DOCTYPE html/>
<html>
	<head>
		<meta charset="utf-8"/>
		<link rel="shortcut icon" href="img/favicon.png">
		<title>ScanFood</title>
		<link rel="stylesheet" href="css/style.css" type="text/css"/>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
		<script src="js/perehod.js"></script>
		<script src="js/adaptetion.js"></script>
	</head>
	<body>
		<div id="top"></div>
		<?php 
			include ('inc/header.php');
		?>
		<div class="blockWrapp">
			<div class="wrap">
				<div class="block">
					<div class="blockLeft">
						<img id="ipad" src="img/ipad.png" align="middle"/>
						<br/>
						<p align="center">Скачать приложение</p><br/>
						<div class="app"><a href="http://www.apple.com" target="_blank"><img src="img/itunes.png"/></a></div>
						<div class="app"><a href="https://play.google.com/store?hl=ru" target="_blank"><img src="img/google_play.png"/></a></div>
						<div class="app"><a href="http://www.microsoftstore.com/store/msusa/en_US/home" target="_blank"><img src="img/windows.png"/></a></div>
					</div>
					<div class="blockRight">
						<h3>Think what you eat…</h3><br />
						<p class="whatEat">ScanFood – первый в Мире сканер продуктов питания, который всегда с Вами! (приложение для смартфонов и планшетов, который расскажет Вам все о еде, которую Вы собираетесь съесть..)</p><br />
						<p class="whatEat">ScanFood - это приложение для смартфонов на Android, iOs, WindowsPhone которое в считанные секунды сообщит Вам, какие опасные химические вещества, аллергены и  добавки содержатся в продукте питания, который Вы хотите приобрести и использовать в пищу. Как эти добавки могут повлиять на Ваш организм. И стоит ли вообще это есть!</p>
						<hr class="hrDotted">
						<p>Как работает</p>
						<div class="blockBlock">
							<div class="blockRightLeft">
								<p>Приложение сканирует штрих-код</p>
							</div>
							<div class="blockRightRight">
								<img src="img/bar-code.png" />
							</div>
						</div>
						<div class="blockBlock">
							<div class="blockRightLeft">
							<p>Отправляет запрос на сервер</p>
							</div>
							
							<div class="blockRightRight">
								<img src="img/server.png" />	
							</div>
						</div>
						<div class="blockBlock">
							<div class="blockRightLeft">
								<p>По штрих-коду находится продукт</p>
							</div>
							<div class="blockRightRight">
								<img src="img/bar-milk.png" />
							</div>
						</div>
						<div class="blockBlock">
							<div class="blockRightLeft">
							<p>Идет поиск состава "Ешек" в продукте</p>
							</div>
							<div class="blockRightRight">
								<img src="img/e-127.png" />
							</div>
						</div>
						<div class="blockBlock">
							<div class="blockRightLeft">
							<p>Выводится результат "Ешек"</p>
							</div>
							<div class="blockRightRight">
								<img src="img/eshki.png" />
							</div>
						</div>
						<div class="blockBlock">
							<div class="blockRightLeft">
							<p>Получение результата о продукте</p>
							</div>
							<div class="blockRightRight">
								<img src="img/result.png" />
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div style="position: relative;"class="blockWrapp">
			<img src="img/girl.jpg" width="100%" usemap="girl">
			<div class="socBtn">
				<a target="_blank" href="http://vk.com"><img src="img/vk.png" alt=""></a>
				<a target="_blank" href="http://odnoklassniki.ru"><img src="img/od.png" alt=""></a>
				<a target="_blank" href="http://fb.com"><img src="img/fb.png" alt=""></a>
				<a target="_blank" href="http://twitter.com"><img src="img/twitter.png" alt=""></a>
				<a target="_blank" href="http://google.com"><img src="img/google.png" alt=""></a>
			</div>
		</div>
		<!-- VIDEO -->
		<div id="top1"></div>
		<?php 
			include ('inc/header.php');
		?>
		<div class="blockWrapp" >
			<div class="wrap">
				<div class="block">
					<iframe width="600" height="400" src="https://www.youtube.com/embed/0ST7U86WWCs" frameborder="0" allowfullscreen></iframe>
					<div class="border">
						<p class="video-maintext">Поход по злачным <br/>местам АТБ</p>
						<p class="video-submaintext">Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. </p>
					</div>
					
					<div class="blockVideoWrapp">
						<div class="blockVideo">
							<iframe width="100%" height="200" src="https://www.youtube.com/embed/0ST7U86WWCs" frameborder="0" allowfullscreen></iframe>
							<p class="blockSmallVideoText">Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. </p>
							<hr/>
						</div>
						
						<div class="blockVideo">
							<iframe width="100%" height="200" src="https://www.youtube.com/embed/0ST7U86WWCs" frameborder="0" allowfullscreen></iframe>
							<p class="blockSmallVideoText">Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. </p>
							<hr/>

						</div>
						
						<div class="blockVideo">
							<iframe width="100%" height="200" src="https://www.youtube.com/embed/0ST7U86WWCs" frameborder="0" allowfullscreen></iframe>
							<p class="blockSmallVideoText">Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. </p>
							<hr/>

						</div>
					</div>
				</div>
				<div class="footer">
					<p class="video-mainfootertext">Поход по злачным местам АТБ</p>
					<p class="video-SubFooterText">Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно пережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.</p>
				</div>
				<br/>
			</div>
		</div>
		<!-- BAR-CODE -->
		<div id="top2"></div>
		<?php 
			include ('inc/header.php');
		?>
		<div class="blockBarBack" name="top2">
		</div>
		<!-- PARTNERS -->
		<div id="top3"></div>
		<?php 
			include ('inc/header.php');
		?>
		<div  class="blockWrapp" >
			<div name="top3" class="wrap">
				<img class="silpo" src="img/silpo.png">
				<div >
					<p class="video-maintext">Официальный магазин партнер "Сильпо"</p>
					<p><br/>Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно пережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.<br/><br/></p>
					<p>Многие думают, что Lorem Ipsum - взятый с потолка псевдо-латинский набор слов, но это не совсем так. Его корни уходят в один фрагмент классической латыни 45 года н.э., то есть более двух тысячелетий назад. Ричард МакКлинток, профессор латыни из колледжа Hampden-Sydney, штат Вирджиния, взял одно из самых странных слов в Lorem Ipsum, "consectetur", и занялся его поисками в классической латинской литературе. В результате он нашёл неоспоримый первоисточник Lorem Ipsum в разделах 1.10.32 и 1.10.33 книги "de Finibus Bonorum et Malorum" ("О пределах добра и зла"), написанной Цицероном в 45 году н.э. Этот трактат по теории этики был очень популярен в эпоху Возрождения. Первая строка Lorem Ipsum, "Lorem ipsum dolor sit amet..", происходит от одной из строк в разделе 1.10.32<br/><br/></p>
					<p>Классический текст Lorem Ipsum, используемый с XVI века, приведён ниже. Также даны разделы 1.10.32 и 1.10.33 "de Finibus Bonorum et Malorum" Цицерона и их английский перевод, сделанный H. Rackham, 1914 год.<br/><br/></p>
				<hr class="partners-hr"/>
				</div>
				<div class="atb">
					<img src="img/atb-1.png">
					<img src="img/atb-2.png">
					<img src="img/atb-3.png">
					<img src="img/atb-4.png">
					<img src="img/atb-5.png">
					<img src="img/atb-6.png">
				</div>
			</div>
		</div>
		<!-- CONTACTS -->
		<div id="top4"></div>
		<?php 
			include ('inc/header.php');
		?>
		<script>
			document.getElementById('feedback-form').onsubmit = function(){
			  var http = new XMLHttpRequest();
			  http.open("POST", "inc/post-1.php", true);
			  http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			  http.send("nameFF=" + this.nameFF.value + "&telFF=" + this.contactFF.value);
			  http.onreadystatechange = function() {
				if (http.readyState == 4 && http.status == 200) {
				  alert(http.responseText + ', Ваше сообщение получено.\nМы свяжемся с Вами\nБлагодарим за интерес к нашей фирме!');
				}
			  }
			  http.onerror = function() {
				alert('Извините, данные не были переданы');
			  }
			  return false;
			}
		</script>
		<div class="contactsWrapp" name="top4">
			<div class="wrap">
				<!-- action где выполнять обработку - # у себя же на странице, или /obrabotchi.php ссылка на скрипт-->
				<form action="js/feedback.php" method="post" class="feedback-form">
					<input type="text" name="name" placeholder="Имя"  required />
					<input type="email" name="email" placeholder="E-mail" required />
					<input type="text" name="phone"  placeholder="Телефон"  required />
					<div class="contact-send">
						<textarea name="message" placeholder="Текст сообщения:" rows="12" required ></textarea>
						<input type="submit" name="submit" value="ОТПРАВИТЬ">
					</div>
				</form>
				
			</div>
		</div>
		<div class="footer">
			<p>63000</p>
			<p>г. Новосибирск</p>
			<p>ул. Лесосечная 18, пом. II</p>
			<br/>
			<p>доп. номер: +7 923 104 40 40</p>
			<p>тел:8-(383)-328-40-01</p>
			<p>факс:8-(383)-328-40-01</p>
			<p>e-mail:http://eltsovcky@yandex.ru</p>
			<div class="socBtnContact">
				<a target="_blank" href="http://vk.com"><img src="img/vk.png" alt=""></a>
				<a target="_blank" href="http://odnoklassniki.ru"><img src="img/od.png" alt=""></a>
				<a target="_blank" href="http://fb.com"><img src="img/fb.png" alt=""></a>
				<a target="_blank" href="http://twitter.com"><img src="img/twitter.png" alt=""></a>
			<a target="_blank" href="http://google.com"><img src="img/google.png" alt=""></a>
			</div>
		</div>
	</body>
</html>