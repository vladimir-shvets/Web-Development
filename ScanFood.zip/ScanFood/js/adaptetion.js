if (window.devicePixelRatio !== 1) {
	var dpt = window.devicePixelRatio;
	var widthM = 0;
	var widthH = 0;
	if(window.innerWidth){     
		widthM = window.innerWidth;     
		widthH = window.innerHeight;
	} else if(document.documentElement && document.documentElement.clientWidth){ 
				widthM = document.documentElement.clientWidth;
				widthH = document.documentElement.clientHeight;
			}   else if(document.body && document.body.clientWidth){
							widthM = document.body.clientWidth;
							widthH = document.body.clientHeight;
					} 
	var deviceAgent = navigator.userAgent.toLowerCase();
	var agentID = deviceAgent.match(/(iphone|ipod|ipad|android|iemobile|ppc|smartphone|blackberry|webos|)/);
	if (agentID) {
		document.write('<meta name="viewport" content="width=' + widthM / dpt + ', initial-scale=1.0, maximum-scale=1.0 user-scalable=yes"">');
	}
	else {
		document.write('<meta name="viewport" content="width=' + widthM + ', initial-scale=1.0, maximum-scale=1.0 user-scalable=yes>');
	}			
};

function scall_site() {
	var coeff = $('html').width()/$('body').width();
	if (coeff>1) coeff=1;
	if (coeff!=1.0) {
		if (navigator.userAgent.indexOf('Firefox')!=-1) 
			$('body').css('box-shadow','none');
		$('body').css('-webkit-transition','scale('+coeff+')');
		$('body').css('-moz-transition','scale('+coeff+')');
		$('body').css('-ms-transition','scale('+coeff+')');
		$('body').css('-o-transition','scale('+coeff+')');
		$('body').css('transform','scale('+coeff+')');
		$('body').height($('html').height()/coeff);
		$('body').width($('html').width()/coeff);
	}else{
		$('body').css('-webkit-transition','scale(1)');
		$('body').css('-moz-transition','scale(1)');
		$('body').css('-ms-transition','scale(1)');
		$('body').css('-o-transition','scale(1)');
		$('body').css('transform','scale(1)');
		$('body').height('100%');
		$('body').width('100%');
	}
}

$(document).ready(function(){
	$( window ).resize(function(){
		scall_site();
	});
	scall_site();
});
