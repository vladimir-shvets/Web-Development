<!DOCTYPE html/>
<html>
	<head>
		<meta charset="utf-8"/>
		<link rel="shortcut icon" href="img/favicon.png">
		<title>ScanFood</title>
		<link rel="stylesheet" href="css/style.css" type="text/css"/>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
		<script src="js/adaptetion.js"></script>
	</head>
	
	
	<body>
		<?php 
			include ('inc/header.php');
		?>
		
		<div class="blockWrapp">
			<div class="wrap">
				<img class="silpo" src="img/silpo.png">
				
				<div>
					<p class="video-maintext">Официальный магазин партнер "Сильпо"</p>
					<p><br/>Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно пережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.<br/><br/></p>

<p>Многие думают, что Lorem Ipsum - взятый с потолка псевдо-латинский набор слов, но это не совсем так. Его корни уходят в один фрагмент классической латыни 45 года н.э., то есть более двух тысячелетий назад. Ричард МакКлинток, профессор латыни из колледжа Hampden-Sydney, штат Вирджиния, взял одно из самых странных слов в Lorem Ipsum, "consectetur", и занялся его поисками в классической латинской литературе. В результате он нашёл неоспоримый первоисточник Lorem Ipsum в разделах 1.10.32 и 1.10.33 книги "de Finibus Bonorum et Malorum" ("О пределах добра и зла"), написанной Цицероном в 45 году н.э. Этот трактат по теории этики был очень популярен в эпоху Возрождения. Первая строка Lorem Ipsum, "Lorem ipsum dolor sit amet..", происходит от одной из строк в разделе 1.10.32<br/><br/></p>

<p>Классический текст Lorem Ipsum, используемый с XVI века, приведён ниже. Также даны разделы 1.10.32 и 1.10.33 "de Finibus Bonorum et Malorum" Цицерона и их английский перевод, сделанный H. Rackham, 1914 год.<br/><br/></p>

				<hr class="partners-hr"/>
				</div>
				
				<div class="atb">
					<img src="img/atb-1.png">
					<img src="img/atb-2.png">
					<img src="img/atb-3.png">
					<img src="img/atb-4.png">
					<img src="img/atb-5.png">
					<img src="img/atb-6.png">
				</div>
				
			</div>
		</div>
	
	</body>


</html>