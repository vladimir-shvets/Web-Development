<!DOCTYPE html/>
<html>

	<head>
		<meta charset="utf-8"/>
		<link rel="shortcut icon" href="img/favicon.png">
		<title>ScanFood</title>
		<link rel="stylesheet" href="css/style.css" type="text/css"/>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
		<script src="js/adaptetion.js"></script>
	</head>
	<body>
		<?php 
			include ('inc/header.php');
		?>
		<div class="blockWrapp">
			<div class="wrap">
				<div class="block">
					<iframe width="600" height="400" src="https://www.youtube.com/embed/0ST7U86WWCs" frameborder="0" allowfullscreen></iframe>
					<div class="border">
						<p class="video-maintext">Поход по злачным <br/>местам АТБ</p>
						<p class="video-submaintext">Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. </p>
					</div>
					
					<div class="blockVideoWrapp">
						<div class="blockVideo">
							<iframe width="100%" height="200" src="https://www.youtube.com/embed/0ST7U86WWCs" frameborder="0" allowfullscreen></iframe>
							<p class="blockSmallVideoText">Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. </p>
							<hr/>
						</div>
						
						<div class="blockVideo">
							<iframe width="100%" height="200" src="https://www.youtube.com/embed/0ST7U86WWCs" frameborder="0" allowfullscreen></iframe>
							<p class="blockSmallVideoText">Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. </p>
							<hr/>

						</div>
						
						<div class="blockVideo">
							<iframe width="100%" height="200" src="https://www.youtube.com/embed/0ST7U86WWCs" frameborder="0" allowfullscreen></iframe>
							<p class="blockSmallVideoText">Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. </p>
							<hr/>

						</div>
					</div>
				</div>
				
				
				<div class="footer">
					<p class="video-mainfootertext">Поход по злачным местам АТБ</p>
					<p class="video-SubFooterText">Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно пережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.</p>
				</div>
				<br/>
			</div>
		</div>
		
		
		
		

	</body>

</html>